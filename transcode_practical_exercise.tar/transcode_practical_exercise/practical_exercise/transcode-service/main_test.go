package transcode_service

import (
	"github.com/go-playground/validator/v10"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestTranscodeParametersValidation(t *testing.T) {
	testCases := []struct {
		name               string
		transcodeType      string
		priority           int
		sourceURL          string
		previewDestination string
		previewSource      string
		subtitleLanguage   string
		subtitleFileExt    string
		errorTestCase      bool
	}{
		{"goodValidation", "testTranscodeType", 1, "testURL", "testDest", "testPreviewSource", "testSubLang", "testSubFile", false},
		{"badTranscodeTypeValidation", "", 1, "testURL", "testDest", "testPreviewSource", "testSubLang", "testSubFile", true},
		{"badSourceURLValidation", "testTranscodeType", 1, "", "testDest", "testPreviewSource", "testSubLang", "testSubFile", true},
		{"badPreviewDestinationValidation", "testTranscodeType", 1, "testURL", "", "testPreviewSource", "testSubLang", "testSubFile", true},
		{"badPreviewSourceValidation", "testTranscodeType", 1, "testURL", "testDest", "", "testSubLang", "testSubFile", true},
		{"badSubtitleLanguageValidation", "testTranscodeType", 1, "testURL", "testDest", "testPreviewSource", "", "testSubFile", true},
		{"badSubtitleFileExtValidation", "testTranscodeType", 1, "testURL", "testDest", "testPreviewSource", "testSubLang", "", true},
	}

	paramsValidator := ParametersValidator{validator: validator.New()}

	for _, testCase := range testCases {
		t.Run(testCase.name, func(t *testing.T) {
			parameters := TranscodeParameters{
				Priority:      testCase.priority,
				TranscodeType: testCase.transcodeType,
				SourceURL:     testCase.sourceURL,
				PreviewParams: PreviewParameters{
					Destination:   testCase.previewDestination,
					PreviewSource: testCase.previewSource},
				Subtitles: []SubtitleParams{
					{SubtitleLanguage: testCase.subtitleLanguage, SubtitleFileExt: testCase.subtitleFileExt},
				},
			}
			err := paramsValidator.Validate(parameters)
			if testCase.errorTestCase {
				assert.Error(t, err, "validation should fail")
			} else {
				assert.NoError(t, err, "validation should be completed without an error")
			}
		})
	}
}

func TestDefaultPreviewParameters(t *testing.T) {
	transcodeParams := TranscodeParameters{}
	fillDefaultsParams(transcodeParams)
	defaultPreview := defaultPreviewParams()

	// check if all parameters inside PreviewParams are the default ones
	assert.Equal(t, transcodeParams.PreviewParams, defaultPreview, "PreviewParams fields should be the same as default ones")
}
