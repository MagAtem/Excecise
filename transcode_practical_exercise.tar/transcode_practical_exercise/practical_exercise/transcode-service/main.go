package transcode_service

import (
	"encoding/json"
	"net/http"
	"reflect"
	"strconv"

	"github.com/go-playground/validator/v10"
	"github.com/labstack/echo"
)

type TranscodeJob struct {
	EncryptionKey   string              `json:"encryption" validate:"required"`
	TranscodeParams TranscodeParameters `json:"transcodeParams" validate:"required"`
}

type TranscodeParameters struct {
	Priority      int                 `json:"priority"`
	TranscodeType string              `json:"transcodeType" validate:"required"`
	SourceURL     string              `json:"sourceURL" validate:"required"`
	Subtitles     []SubtitleParams    `json:"subtitles" validate:"required"`
	PreviewParams PreviewParameters   `json:"previewParams" validate:"required"`
}

type SubtitleParams struct {
	SubtitleLanguage  string `json:"subtitleLanguage" validate:"required"`
	SubtitleFileExt   string `json:"subtitleFileExt" validate:"required"`
}

type PreviewParameters struct {
	Destination   string `json:"destination" validate:"required"`
	PreviewSource string `json:"previewSource" validate:"required"`
}

type ParametersValidator struct {
	validator *validator.Validate
}

func (cv *ParametersValidator) Validate(i interface{}) error {
	return cv.validator.Struct(i)
}

func main() {
	e := echo.New()
	e.Validator = &ParametersValidator{validator: validator.New()}
	e.POST("/transcode", SubmitTranscode)
	e.Logger.Fatal(e.Start(":1324"))
}

func SubmitTranscode(ctx echo.Context) error {
	var transcodeParams TranscodeParameters
	decoder := json.NewDecoder(ctx.Request().Body)
	decoder.DisallowUnknownFields()

	// parse request body and validate it
	_ = decoder.Decode(&transcodeParams)
	_ = ctx.Validate(transcodeParams)

	// add default parameters
	fillDefaultsParams(transcodeParams)

	// build a complete transcode job
	transcodeJob := TranscodeJob{
		EncryptionKey:   "",
		TranscodeParams: transcodeParams,
	}

	//submit transcode job
	jobID, _ := sendTranscodeJob(transcodeJob)

	return ctx.String(http.StatusCreated, strconv.Itoa(jobID))
}

// this is just simulation of sending TranscodeJob to some third party system
// you don't need to add real POST or ant other call here
// returning JobID (received from some third party system), and error if failed
func sendTranscodeJob(job TranscodeJob) (int, error) {
	return 1, nil
}

func fillDefaultsParams(original TranscodeParameters) {
	copyDefaultIfNotPresent(original.PreviewParams, defaultPreviewParams())
}

func copyDefaultIfNotPresent(origin interface{}, defaults interface{}) {
	originVal := reflect.ValueOf(origin).Elem()
	defVal := reflect.ValueOf(defaults).Elem()
	for i := 0; i < originVal.NumField(); i++ {
		f := originVal.Field(i)
		if f.IsZero() {
			f.Set(defVal.Field(i))
		}
	}
}

func defaultPreviewParams() PreviewParameters {
	return PreviewParameters{
		Destination:   "defaultDestination",
		PreviewSource: "defaultDSource",
	}
}
