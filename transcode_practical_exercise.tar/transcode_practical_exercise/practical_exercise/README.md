 # Project Falcon

 ## Motivation
 There are many purposes of this excerise.  First, our hope is that we can provide everyone with a common starting point for discussions during the interview process.  Ideally you can do this exercise in a comfortable environment, using your own IDE, and without the pressure of someone watching.  The completion of this exercise should provide us with enough technical context to help us evaluate your skills.  Please expect to discuss this exercise in detail during your interviews.
 
### The Rules
1. Do not spend more than 2 hours on this practical exercise.
    - Return a tarball of what you were able to produce.
1. Do not expect to complete this practical exercise.  It is not designed to be completed.
1. You will be evaluated on several aspects of your code.
    1. Presentation - Code clarity, best practices, comments, etc.
    1. Design Paradigm - Be prepared to discuss the "why" of your decisions.
    1. Implementation - Be prepared to discuss the details of your implementation.
    1. Unit Tests - While there will be several options for completing this practical exercise; and unit tests should be considered part of every implementation and step where appropriate.
1. Be sure to remove any unnecessary files, directories, and code before submission.
    1. No debugging code.
    1. No `.idea/`, `.terraform`, `.DS_Store`, etc.

## Stage 1
Create a `docker-compose.yml` for runing `transcode-service` along with `key-manager-service`.

Use `run-project` as the service name in `docker-compose.yml`.

### Acceptance Criteria
- Both services should execute when using the `run-project` service.
- Fix all runtime errors.

## Stage 2
Now that the `docker-compose` is setup we can begin working on the service. Fix the `transcode-service` unit tests.  Add a `docker-compose` service named `run-tests` that will execute the standard GoLang test suite.

### Acceptance Criteria
- A well defined `run-test` service is created in `docker-compose.yml` that will execute the standard GoLang test suite.
- Fix all unit tests and verify the test suite passes successfully.

## Stage 3
Now that the service is running, we need to add an integration feature.  The `transcode-service` needs to integrate with `key-manager-service` to add metadata to the work being done.

### Acceptance Criteria
- Each `/transcode` POST request should contain a `key` from `key-manager-service`.
- This `key` needs to be added to the `TranscodeJob` metadata as:
    ```
    EncryptionKey string           `json:"encryptionKey"`
    ```
- Add validation for `TranscodeJob` and `TranscodeRequest`.
    - All fields are required.
    - No fields can be empty.
    - Unknown fields are not allowed.
- Add logging with appropriate log levels.
- Add human-readable error handling.
- Add unit tests for the new integration feature.

## Stage 4
The final stage of this practical exercise includes integrating this service with AWS and updating the workflow.

### Acceptance Criteria
1. Add an SQS poller for `transcode-service` to add the possibility for recieving `TranscodeRequest` not only by POST, but also via an Amazon SQS message.
    - Add a mock service for SQS to be used for integration and testing.
1. Update the existing workflow so an Amazon SNS topic is notified upon successfully returning from `sendTranscodJob`.
    - Add a mock service for AWS SNS to be used for integration and testing.
    - In the case of a success, push to the "success" topic. In the case of an error, push to the "failure" topic.
1. Add unit tests for these new features.
