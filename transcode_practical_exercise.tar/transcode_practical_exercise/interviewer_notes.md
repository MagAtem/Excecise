# Project Falcon Interview Notes
## Issues with Validation
- Validation for `SubtitleParams` field should use the `dive` property.  In another case the Validator will not check elements inside the slice.

### Issues with Pointers / Pass by Reference vs Pass by Value
- The `fillDefaultsParams()` func should recieve a pointer, in another case the default parameters will be not be injected inside the original `TranscodeParameters`.
- `copyDefaultIfNotPresent()` should also operate with pointers, call of `reflect.Value.Elem` should executed only on interfaces or pointers. This execution will throw a `panic !!` with structs.

### Issues with Unit Tests
- The two unit tests in the original `transcode-service` codebase will fail until all issues listed above are fixed.

## Questions to Ask
- Discuss the context package, https://golang.org/pkg/context/. Echo context as an example. 
  - How is this package supposed to be use?  What is the purpose?  What problems does it solve?

## Unfinished Tasks
Note where the candidate finished the exercise.  We expect the candidate to stop during Stage 4; but there are no expectations around this.  No matter where the candidate stops the exercise, expect to follow up with them about the anticipated next steps.

### SQS Poller
For example, if candidate was not be able to deliver "SQS poller" portion of the exercise, then expand on the concept exploring for the candidate's knowledge.
- Concurrency, go routines, channels etc.
  - Consider discussing adummy `ReceiveQueueMessages()` func, as a source of messages from the queue.
  - Useful links for some examples of a concurrent "worker":
    - pooller that implement synchronization, with help of chanels:  https://gobyexample.com/worker-pools
    - pooller that implement synchronization, with help of WaitGroup: https://gobyexample.com/waitgroups

Key fetures of such poller:
- A loop that will try to receive messages.
- Go routines that will handle the message.
- Synchronization of go routines, that handle the messages.
- Each message should be handled only once!
- The candidate should not forget about deleting the message from the Queue, after handling it. This can be done with dummy func call, like `DeleteMessage()`, though we don't care about the implementation of mocks.


## Further Notes
Ask about the kinds of channels the candidate is familiar with.
- Q: What is the difference between "buffered" and "unbuffered" channels?
  - A: By default channels are unbuffered, meaning that they will only accept sends (chan <-) if there is a corresponding receive (<- chan) ready to receive the sent value. Buffered channels accept a limited number of values without a corresponding receiver for those values.
- Q: What happens if you write to closed channel?
  - A: Your program will panic.
- Q: Provide an example of how to use `waitGroups`.
  - A: 
- Q: Can you use multiple `defer` statement?
  - A: Yes. A deferred function call is pushed onto a stack. When a function returns, its deferred calls are executed in last-in-first-out order. ===> https://tour.golang.org/flowcontrol/13